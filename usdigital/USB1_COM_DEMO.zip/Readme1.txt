US Digital Corporation

USB1 VB and MFC Demo Installation Information 
OS: Windows 98/ME, Windows 2000/XP
Date: 12-02-02

Installed Components:
---------------------------------------------------------------------------------------------------
USB1Server.dll			ActiveX COM component which provides easy to use methods, properties, and events to communicate with USB1 devices.
ModuleDial.ocx			AcitveX User Control which displays the module name, position, resolution, and a graphical dial indicator for each encoder connected to a USB1 device.
ModDialTester.exe		A Visual Basic application demonstrating how to use the basic USB1Server interface.
ModuleDialCtrl_Source.zip	The source code for the ModuleDial.ocx.
ModDialTester_Source.zip	The source code for the ModuleDialTester.exe.
MFCTester_Source.zip		The source code for an MFC application that demostrates the how to use the basic USB1Server interface.
USB1Server_Source.zip		The source code for the USB1Server ActiveX COM Component.

---------------------------------------------------------------------------------------------------
The installation software will automatically install and register the USB1Server.dll and ModuleDial.ocx files.


Programming:
---------------------------------------------------------------------------------------------------
You can use any of the supplied source code as part of your own control software, but we make no guarantees on any part of it.


