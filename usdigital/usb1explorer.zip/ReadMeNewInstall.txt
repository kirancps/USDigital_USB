==================================== NEW INSTALLS =================================================

When you insert the U.S. Digital CD you will be given an opportunity to install the USB1 demo program.
It is advisable to quit other Windows programs before continuing. Click on "Install Product Software."
The CD software will present you with a list of product software; choose one of the USB1 software
packages from the list.  The usual choice is USB1 Demo Software; if you are using Labview there is
a choice for that system, and if you wish to do development with COM components there is a choice
for that as well.

If you are installing a USB1 on your computer for the first time, simply plug in power and connect it
to a cable that is plugged into your USB port (Windows 2000 users should be logged in as administrators).
Windows will notice that new hardware has been connected, and will open a New Hardware Wizard so that
you can install the driver.  Hit Next at the opening screen, and then let Windows search for a driver; 
just be sure that a floppy or CD containing the driver and the INF file is in the drive, and that the
checkboxes next to "search floppy" and �search CD� are checked.

You will find that the USB1 manual is available as a PDF file from the Start menu, alongside the USB1
Demo program. There is also a zip file provided in the "USB1 Explorer" directory under "Program Files";
this zip file contains the USB1_Explorer source, but be advised it is a fairly large program.

Kurt Liebezeit
